
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import React, { useState, useEffect } from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Navbar, Nav, ButtonGroup,Button,Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {   Row, Col } from 'react-bootstrap'; // Make sure to import these components from your UI framework

export default function Student() {
 
  const [studentName, setStudentName] = useState('');

  const [studentId, setStudentId] = useState('');
  const handleNameButtonClick = () => {
    if (studentName.trim() !== '') {
      window.location.href = (`/findbyname/${studentName}`);

    }
  };
  const handleIdButtonClick = () => {
    if (studentId.trim() !== '') {
      window.location.href = `/findbyid/${studentId}`;
    }
  };

  return (
    <div className="App">
      <Navbar bg="info" variant="dark">
        <Navbar.Brand as={Link} to="/Home">
          My App
        </Navbar.Brand>
        <Nav className="mr-auto">
          <Nav.Link as={Link} to="/Home">
            Home
          </Nav.Link>
          <Nav.Link as={Link} to="/ListAllStudents">
            List Students
          </Nav.Link>
          <Nav.Link as={Link} to="/addStudent">
            Add Students
          </Nav.Link>
          <Nav.Link as={Link} to="/addCompany">
            Add Company
          </Nav.Link>
          <Nav.Link as={Link} to="/CompaniesDetails">
            Companies Details
          </Nav.Link>
        </Nav>
      </Navbar>

      <div>
        
<div>
  
  <ButtonGroup>
     <Button align="right" variant="link" as={Link} to="/feespending"className="custom-button">
      Fees pending Students
    </Button>
    <Button variant="link" as={Link} to="/login" className="custom-button">
    login
    </Button>

   
   
  </ButtonGroup>
</div>

    <div>
    <h4 className="custom-heading" align="left">Find student by</h4>

      <Row>
        <Col>
          <Form.Group controlId="studentId">
            <Form.Control
              type="text"
              placeholder="Enter Student ID"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
            />
          </Form.Group>
        </Col>
        <Col>
          <Button variant="link" onClick={handleIdButtonClick}>
            Find by ID
          </Button>
        </Col>
      </Row>
      <Row>
        <Col>
          <Form.Group controlId="studentName">
            <Form.Control
              type="text"
              placeholder="Enter Student Name"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
            />
          </Form.Group>
        </Col>
        <Col>
          <Button variant="link" onClick={handleNameButtonClick}>
            Find by Name
          </Button>
        </Col>
      </Row>
    </div>
      </div>

      <Outlet />
    </div>
  );
}