import React from "react";
import { Link } from "react-router-dom";
import ListFollowUp from "./ListFollowUp";
import { useEffect,useState } from "react";
import { useNavigate } from "react-router-dom";

function Dashboard() {

    const [isloggedin, setIsLoggedin] = useState(false);
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    // useHistory hook to access the history object for navigation
    const navigate = useNavigate();

    // useEffect to check if the user is not logged in, then navigate to the login page
    useEffect(() => {
        const storedUser = localStorage.getItem("token_info");
        if (!storedUser) {
            setIsLoggedin(false);
            navigate('/login');
        }
    }, [navigate]);
    return (
        <div className="dashboard">
            <div className="main-content">
                <h2>Welcome to Staff Dashboard</h2>
                <div className="button-container">
                    <button className="dashboard-button"><Link to="/enquiry">Add Enquiry</Link></button>
                    <button className="dashboard-button"><Link to="/StudentTab">Student</Link></button>
                    <button className="dashboard-button"><Link to="/ListFollowUp">Follow Up</Link></button>
                    <button className="dashboard-button"><Link to="/logout">logout </Link></button>
                </div>
            </div>
            <div className="view-all">
                <Link to="ListFollowUp">View All</Link>
            </div>
            {/* <ListFollowUp /> */}
          {/* <PagingComponent /> */}
        </div>
    );
}

export default Dashboard;
