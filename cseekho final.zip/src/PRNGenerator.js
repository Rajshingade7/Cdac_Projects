import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function PRNIDGenerator() {
    const [studentid, setstudentid] = useState([]);
    const Navigate=useNavigate();

    useEffect(() => {
        fetch("http://localhost:8084/api/students/allStudents")
            .then(res => res.json())
            .then(data => {
                const studentIds = data.map(record => record.student_id);
                setstudentid(studentIds);
            });
    }, []);

    const sendStudentIdsToBackend = (event) => {
        event.preventDefault();
        studentid.forEach(studentId => {
            fetch("http://localhost:8084/api/prn/create/"+1+"/"+studentId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
               // body: JSON.stringify({ studentId: studentId })
            })
            .then(response => response.text())
            .then(data => {
                console.log("done");
            })
            .catch(error => {
                console.error(`Error for studentId ${studentId}:`, error);
            });
        });
        alert("PRN Inserted");
        Navigate('/admin');
    };

    return (
        <div>
            <form onSubmit={sendStudentIdsToBackend}>
                
                <label htmlFor="submit">Click Here to Generate PRN</label>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
}
