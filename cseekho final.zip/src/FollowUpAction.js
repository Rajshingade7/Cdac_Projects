import React from 'react';
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom"
function Follow_upAction() {
    const [Follow_up, setFollow_up] = useState({});
    const [staff, setStaff] = useState([])
    const { id } = useParams();
    const [closuresrc, setClosure] = useState([])
    const [DemoEnq,setDemoEnq]=useState({});


    let navigate = useNavigate();

    
        
    useEffect(() => {
        fetch("http://localhost:8084/api/Closure/ListAll")
          .then(res => res.json())
          .then((result) => { console.log(result); setClosure(result); });
      }, []);

      useEffect(() => {
        fetch("http://localhost:8084/api/staff/ListAll")
          .then(res => res.json())
          .then((result) => { console.log(result); setStaff(result); });
      }, []);
    useEffect(() => {
        fetch("http://localhost:8084/api/follow_up/"+ id)
            .then(res => res.json())
            .then((result) => {
                setFollow_up(result);
                
            }
            ).catch((e) => console.log(e));
    }, []);
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setFollow_up(values => ({ ...values, [name]: value }))
    }
const getEnquiry= ()=>{
    fetch("http://localhost:8084/api/enquiry/"+Follow_up.enquiry_Id)
          .then(res => res.json())
          .then((result) => { console.log(result); setDemoEnq(result); });
       // handleenq()

}

// const handleenq = (event) => {
//     setDemoEnq(values => ({ ...values, [next_followup_Date]: Follow_up.followUp_date }))
//     setDemoEnq(values => ({ ...values, enquirer_Query: Follow_up.followUp_message }))
//     setDemoEnq(values => ({ ...values, closure_Id: Follow_up.closure_Id }))

//     updateenquiry();
// }

const updateenquiry= async ()=>{
     

    fetch("http://localhost:8084/api/enquiry/update/"+Follow_up.enquiry_Id, {
        method: 'PUT',
        headers: { 'Content-type': 'application/json' },
        body: JSON.stringify(DemoEnq)
    }).then(r => { console.log(r) })
}

    const handleSubmit = (event) => {
        event.preventDefault();
        let demo = 
        {
            "followUp_id": id,
            "enquiry_Id": Follow_up.enquiry_Id,
            "followUp_date": Follow_up.followUp_date,
            "attempts": Follow_up.attempts,
            "staff_id": Follow_up.staff_id,
            "closure_Id": Follow_up.closure_Id,
            "followUp_message": Follow_up.followUp_message
        }
        
        fetch("http://localhost:8084/api/follow_up/update/"+ id, {
            method: 'PUT',
            headers: { 'Content-type': 'application/json' },
            body: JSON.stringify(demo)
        }).then(r => { console.log(r) })
        event.preventDefault();
        //updateenquiry();
        navigate('/ListFollowUp');

    }
    return (
        <form className="container" onSubmit={handleSubmit}>
            <label>Id:</label>
            <input
                type="text"
                name="followUp_id"
                value={Follow_up.followUp_id ?? ""}
                disabled={true}
                onChange={handleChange}
            />
            <br />           
              
             <label>followUp_message:</label>
            <input
                type="text"
                name="followUp_message"
                value={Follow_up.followUp_message || ""}
                onChange={handleChange}
            />
            <br />           
             <label>followUp_date:</label>
            <input
                type="Date"
                name="followUp_date"
                value={Follow_up.followUp_date || ""}
                onChange={handleChange}
            />
            <br />            
            <label>attempts:</label>
            <input
                type="number"
                name="attempts"
                value={Follow_up.attempts}
                onChange={handleChange}
            />
            <br/>
            <label htmlFor="staff_Id">Staff Name:</label>
            <select name="staff_id" onChange={ handleChange}>
                <option>Select</option>
                {staff.map(emp => (
                    <option value={emp.staff_Id}>{emp.name}</option>
                ))}
            </select>
            <br />
           <label htmlFor="closure_Id">closure:</label>
        <select name="closure_Id" onChange={ handleChange}>
          <option> selectOption</option>
          {closuresrc.map(emp => (
            <option value={emp.closure_Id}> {emp.clousre_Reason}</option>
          ))}
        </select><br></br>
            <button type="submit" >update</button>
        </form>
    );
} export default Follow_upAction;
