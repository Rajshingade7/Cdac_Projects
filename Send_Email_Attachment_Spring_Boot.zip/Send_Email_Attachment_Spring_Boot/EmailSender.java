package com.example.mail;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class EmailSender 
{
	@Value("${file.path}")
	private String path;
	public void send(String subject,MultipartFile filename,String message)
	{
		final String username = "nitinvijaykar863@gmail.com";
		final String password = "password";
 
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
 
		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });
 
		try {
 
			MimeMessage message1 = new MimeMessage(session);
			message1.setRecipients(Message.RecipientType.TO,
			InternetAddress.parse("nitin.javastudent@gmail.com"));
			message1.setSubject(subject);

			MimeBodyPart part1 = new MimeBodyPart();  
			String name=filename.getOriginalFilename();
			// making the full path
			String filePath=path+File.separator+name;
			DataSource source = new FileDataSource(filePath); 
			System.out.println("File Name is\t"+filePath);
			part1.setDataHandler(new DataHandler(source));  
			part1.setFileName(filePath);  
			
			BodyPart part2 = new MimeBodyPart();  
		    part2.setText(message);  
			
			Multipart multipart = new MimeMultipart();  
			multipart.addBodyPart(part1);
			multipart.addBodyPart(part2);
			
			message1.setContent(multipart);
			Transport.send(message1);
 
			System.out.println("Done completely");
 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
